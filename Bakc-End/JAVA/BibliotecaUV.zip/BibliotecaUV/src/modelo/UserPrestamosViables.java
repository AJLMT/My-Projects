package modelo;

import java.util.Date;

public class UserPrestamosViables extends EstadoUser {

    public UserPrestamosViables(User aUser) {
        super(aUser);
    }

    @Override
    public Respuesta solicitarPrestamo(Libro aLibro) {
   
        Respuesta prestamoSolicitado;

        if (user.comprobarRetrasado()) 
        {
            new UserRetrasado(user);
            prestamoSolicitado = user.solicitarPrestamo(aLibro);  
        } 
        else 
            prestamoSolicitado = user.nuevoPrestamo(aLibro);
       
        return prestamoSolicitado;
    }

    @Override
    public Respuesta solicitarReserva(Libro aLibro) {
         return user.nuevaReserva(aLibro);
    }
}

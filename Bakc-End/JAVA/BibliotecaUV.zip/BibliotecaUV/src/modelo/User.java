package modelo;

import java.util.ArrayList;
import modelo.Prestamo;
import modelo.Libro;

public abstract class User {

    protected String dni;
    protected String nombre;
    protected String apellidos;
    protected String direccion;
    protected String telefono;
    public ArrayList<Prestamo> prestamos = new ArrayList<Prestamo>();
    private ArrayList<Libro> librosReservados = new ArrayList<Libro>();
    private EstadoUser estadoUser;

    public User(String aDNI, String aNombre, String aDireccion, String aTelefono) {
        dni = aDNI;
        nombre = aNombre;
        direccion = aDireccion;
        telefono = aTelefono;
        estadoUser = new UserPrestamosViables(this);
    }

    public Respuesta solicitarPrestamo(Libro aLibro) {
        return estadoUser.solicitarPrestamo(aLibro);
    }

    public Respuesta nuevoPrestamo(Libro aLibro) {
        Respuesta prestamoPosible;
        Ejemplar ejemplar = aLibro.buscarEjemplarDisponible();
        
        if (ejemplar != null)
        {
            Prestamo prestamo = new Prestamo(this, ejemplar, getPlazoMaximo());
            
            prestamoPosible = Respuesta.LIBRO_PRESTADO_EXITO;
            
            prestamoPosible.setComentariosAdicionales("La fecha de devolución prevista es: " + Biblioteca.FORMAT_DATE.format(prestamo.getFechaDevolucionPrevista()));
        }
        else
            prestamoPosible = Respuesta.LIBRO_NO_EJEMPLARES_LIBRES;
        
        return prestamoPosible;
    }

    public Respuesta solicitarReserva(Libro aLibro) {
        return estadoUser.solicitarReserva(aLibro);
    }

    public Respuesta nuevaReserva(Libro aLibro) {
        this.librosReservados.add(aLibro);
        
        aLibro.addReserva(this);
        
        return Respuesta.LIBRO_RESERVADO_EXITO;
    }

    public Respuesta devolverLibro(String aISBN) {
        Respuesta resultadoDevolucion;
        
        Prestamo prestamo = buscarPrestamo(aISBN);

        if (prestamo != null)
        {
            short diasRetraso = prestamo.devolver();
            
            if (diasRetraso == 0)
                resultadoDevolucion = Respuesta.LIBRO_DEVUELTO_EXITO;
            else
            {
                resultadoDevolucion = Respuesta.USER_CON_MULTA;
                resultadoDevolucion.setComentariosAdicionales("La fecha de devolución prevista es: " + Biblioteca.FORMAT_DATE.format(prestamo.getFechaDevolucionPrevista()));
            }
        } 
        else
            resultadoDevolucion = Respuesta.PRESTAMO_NO_EXISTE;
        
        return resultadoDevolucion;
    }

    public Respuesta ponerMulta(short aDias) {
        return estadoUser.ponerMulta(aDias);
    }

    public boolean comprobarDNI(String aDni) {
        return dni.equals(aDni);
    }

    public boolean comprobarRetrasado() {
        boolean retrasado = false;
        int index = 0;
        Prestamo prestamo;

        while (!retrasado && index < prestamos.size()) {
            prestamo = prestamos.get(index++);
            retrasado = (prestamo.comprobarRetrasado() > 0);
        }
        return retrasado;
    }

    public void addPrestamo(Prestamo aPrestamo) {
        prestamos.add(aPrestamo);
    }

    public void removePrestamo(Prestamo aPrestamo) {
        prestamos.remove(aPrestamo);
    }

    public Prestamo buscarPrestamo(String aISBN) {
        int index = 0;
        Prestamo prestamo, prestamoEncontrado = null;

        while (prestamoEncontrado == null && index < prestamos.size()) {
            prestamo = prestamos.get(index++);
            if (prestamo.comprobarLibro(aISBN)) {
                prestamoEncontrado = prestamo;
            }
        }
        return prestamoEncontrado;
    }
    
    public void setEstado(EstadoUser aEstado) {
        this.estadoUser = aEstado;
    }

    public abstract short getNumLibrosMax();

    public abstract short getPlazoMaximo();
}

package modelo;

import java.util.Date;

public class Prestamo {

    private Date fechaInicio;
    private Date fechaDevolucionPrevista;
    private User user;
    protected Ejemplar ejemplar;

    public Prestamo(User aUser, Ejemplar aEjemplar, short aPlazoMax) {
        user = aUser;
        user.addPrestamo(this);
        ejemplar = aEjemplar;
        ejemplar.prestar(this);
        fechaInicio = new Date();
        fechaDevolucionPrevista = (Date) fechaInicio.clone();
        fechaDevolucionPrevista.setMonth(fechaDevolucionPrevista.getMonth() + aPlazoMax);
    }

    public short devolver() {
        short diasRetraso = comprobarRetrasado();
        user.removePrestamo(this);
        ejemplar.devolver();
        return diasRetraso;
    }

    public boolean comprobarLibro(String aISBN) {
        return ejemplar.comprobarLibro(aISBN);
    }

    public short comprobarRetrasado() {
        short diasRetraso = 0;
        Date hoy = new Date(); //Fecha de hoy 
        long diferencia = (fechaDevolucionPrevista.getTime() - hoy.getTime())/Biblioteca.MILLSECS_PER_DAY;
        if (diferencia<0)
            diasRetraso = (short)Math.abs(diferencia);
        return diasRetraso;
    }

    public Date getFechaDevolucionPrevista() {
        return fechaDevolucionPrevista;
    }

    public void setUser(User aUser) {
        this.user = aUser;
    }

    public User getUser() {
        return this.user;
    }

    public void setEjemplar(Ejemplar aEjemplar) {
        this.ejemplar = aEjemplar;
    }

    public Ejemplar getEjemplar() {
        return this.ejemplar;
    }
    
    public void forzarRetraso(short numDias) {
        fechaDevolucionPrevista=new Date();
        fechaDevolucionPrevista.setDate(fechaDevolucionPrevista.getDate()-numDias);
    }
}

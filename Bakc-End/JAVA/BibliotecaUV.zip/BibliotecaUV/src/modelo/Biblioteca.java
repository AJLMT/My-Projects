package modelo;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class Biblioteca {
    /**
     * Generador de códigos para los ejemplares
     */
    private static short codigosEjemplares = 0;
    /**
     * Milisegundos al día
     */
    public static long MILLSECS_PER_DAY = 24 * 60 * 60 * 1000;
    /**
     * Formateo de fechas
     */
    public static final SimpleDateFormat FORMAT_DATE = new SimpleDateFormat("dd-MM-yyyy");

    private ArrayList<User> users = new ArrayList<User>();
    private ArrayList<Libro> libros = new ArrayList<Libro>();
    private User userAct;
    private Libro libroAct;

    public Biblioteca() {
    }

    public Respuesta solicitarPrestamoLibro(String aIsbn, String aDni) {
        this.userAct = this.buscarUser(aDni);
        Respuesta prestamoPosible;
        
        if (userAct != null) 
        {
            libroAct = this.buscarLibro(aIsbn);
            
            if (libroAct != null)
                prestamoPosible = userAct.solicitarPrestamo(libroAct);
            else
                prestamoPosible = Respuesta.LIBRO_NO_EXISTE;
        } 
        else 
            prestamoPosible = Respuesta.USER_NO_EXISTE;
        
        
        return prestamoPosible;
    }

    public Respuesta reservarLibro() {
        return userAct.nuevaReserva(libroAct);
    }

    public Respuesta devolverLibro(String aDNI, String aISBN) {
        userAct = buscarUser(aDNI);
        Respuesta reservaPosible;
        
        if (userAct != null) 
        {
            reservaPosible = userAct.devolverLibro(aISBN);
        } 
        else 
        {
            reservaPosible = Respuesta.USER_NO_EXISTE;
        }
        
        return reservaPosible;
    }

    public Respuesta ponerMulta(short aDias) {
        return userAct.ponerMulta(aDias);
    }

    public User buscarUser(String aDni) {
        int indice = 0;
        User user; 
        User userEncontrado = null;

        while (userEncontrado == null && indice < users.size()) 
        {
            user = users.get(indice++);
            
            if (user.comprobarDNI(aDni)) 
            {
                userEncontrado = user;
            }
        }
        
        return userEncontrado;
    }

    public Libro buscarLibro(String aIsbn) {
        int index = 0;
        Libro libro;
        Libro libroEncontrado = null;

        while (libroEncontrado == null && index < libros.size()) 
        {
            libro = libros.get(index++);
            
            if (libro.comprobarISBN(aIsbn)) 
            {
                libroEncontrado = libro;
            }
        }
        
        return libroEncontrado;
    }

    public void iniciar() {
        Libro libro1 = new Libro("000", "La historioa interminable", "J.R. Tolkien");
        Libro libro2 = new Libro("001", "El señor de los anillos", "J.R. Tolkien");
        libros.add(libro1);
        libros.add(libro2);

        Ejemplar ejem1_libro1 = new Ejemplar(nuevoCodigoEjemplar(), libro1);
        Ejemplar ejem2_libro1 = new Ejemplar(nuevoCodigoEjemplar(), libro1);

        Ejemplar ejem1_libro2 = new Ejemplar(nuevoCodigoEjemplar(), libro2);
        Ejemplar ejem2_libro2 = new Ejemplar(nuevoCodigoEjemplar(), libro2);

        Student student1 = new Student("1", "Pepe", "Aquí", "123");
        PDI proff1 = new PDI("2", "Pepa", "Allí", "456");
        users.add(student1);
        users.add(proff1);

        //Para probar las sanciones
        Respuesta resultado = proff1.solicitarPrestamo(libro1);
        ejem1_libro1.forzarRetraso((short) 5);
    }

    public String nuevoCodigoEjemplar() {
        return String.valueOf(codigosEjemplares++);
    }

}

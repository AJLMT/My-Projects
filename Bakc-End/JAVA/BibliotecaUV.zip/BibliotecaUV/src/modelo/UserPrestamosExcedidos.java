package modelo;

public class UserPrestamosExcedidos extends EstadoUser {

    public UserPrestamosExcedidos(User aUser) {
        super(aUser);
    }

    @Override
    public Respuesta solicitarPrestamo(Libro aLibro) {
        return Respuesta.USER_MAX_PRESTAMOS;
    }

    @Override
    public Respuesta solicitarReserva(Libro aLibro) {
        return Respuesta.USER_MAX_PRESTAMOS;
    }
}

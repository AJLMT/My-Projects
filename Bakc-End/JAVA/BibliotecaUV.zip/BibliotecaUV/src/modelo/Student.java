package modelo;

public class Student extends User {

    private static short numLibrosMax = 6;
    /**
     * 1 mes
     */
    private static short plazoMaximo = 1;

    public Student(String aDNI, String aNombre, String aDireccion, String aTelefono) {
        super(aDNI, aNombre, aDireccion, aTelefono);
    }

    @Override
    public short getNumLibrosMax() {
        return Student.numLibrosMax;
    }

    @Override
    public short getPlazoMaximo() {
        return Student.plazoMaximo;
    }

    @Override
    public String toString() {
        return (getClass().toString() + ": " + dni + " " + nombre + " " + direccion + " " + telefono);
    }
}

package modelo;

public class PDI extends User {

    private static short numLibrosMax = 12;
    /**
     * 6 meses
     */
    private static short plazoMaximo = 6;

    public PDI(String aDNI, String aNombre, String aDireccion, String aTelefono) {
        super(aDNI, aNombre, aDireccion, aTelefono);
    }

    @Override
    public short getNumLibrosMax() {
        return PDI.numLibrosMax;
    }

    @Override
    public short getPlazoMaximo() {
        return PDI.plazoMaximo;
    }

    @Override
    public String toString() {
        return (getClass().toString() + ": " + dni + " " + nombre + " " + direccion + " " + telefono);
    }
}

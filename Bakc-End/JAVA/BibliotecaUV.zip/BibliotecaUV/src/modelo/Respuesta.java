package modelo;

public enum Respuesta {
    LIBRO_PRESTADO_EXITO((short) 1, "Libro prestado con éxito"),
    LIBRO_RESERVADO_EXITO((short) 2, "Libro reservado con éxito"),
    LIBRO_DEVUELTO_EXITO((short) 3, "Libro devuelto con éxito"),
    MULTA_IMPUESTA_EXITO((short) 4, "Multa impuesta con éxito"),
    ERROR((short) 0, "Error no definido"),
    LIBRO_NO_EXISTE((short) -1, "Libro no existe"),
    LIBRO_NO_EJEMPLARES_LIBRES((short) -2, "No quedan ejemplares libres del libro"),
    USER_NO_EXISTE((short) -3, "No existe usuari@ con ese DNI"),
    USER_MAX_PRESTAMOS((short) -4, "Usuari@ tiene máximo ejemplares prestados"),
    USER_CON_MULTA((short) -5, "Usuari@ tiene una multa"),
    USER_CON_RETRASO((short) -6, "Usuari@ tiene ejemplares retrasados pendientes de devolucion"),
    PRESTAMO_NO_EXISTE((short) -7, "Usuari@ no tiene ese libro en prestamo");

    private short value;
    private String comentario;
    private String comentariosAdicionales;

    Respuesta(short v, String coment) {
        value = v;
        comentario = coment;
        comentariosAdicionales = "";
    }

    public boolean hayError() {
        return value <= 0;
    }

    public void setComentariosAdicionales(String aComentariosAdicionales) {
        comentariosAdicionales = aComentariosAdicionales;
    }

    @Override
    public String toString() {
        return comentario + " " + comentariosAdicionales;
    }
}

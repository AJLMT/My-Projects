package modelo;

public class Ejemplar {
    private String codigo;
    private Libro libro;
    public Prestamo prestamo;

    public Ejemplar(String aCodigo, Libro aLibro) {
        codigo = aCodigo;
        libro = aLibro;
        libro.addEjemplar(this);
    }

    public boolean comprobarDisponible() {
        return (prestamo == null);
    }

    public void prestar(Prestamo aPrestamo) {
        prestamo = aPrestamo;
    }

    public void devolver() {
        prestamo = null;
    }

    public boolean comprobarLibro(String aISBN) {
        return libro.comprobarISBN(aISBN);
    }
    
    public void forzarRetraso(short numDias) {
        if (prestamo!=null)
            prestamo.forzarRetraso(numDias);
    }
}

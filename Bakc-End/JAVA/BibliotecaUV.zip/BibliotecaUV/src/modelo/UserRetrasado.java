package modelo;

public class UserRetrasado extends EstadoUser {
    public UserRetrasado(User aUser) {
        super(aUser);
    }

    @Override
    public Respuesta solicitarPrestamo(Libro aLibro) {
        return Respuesta.USER_CON_RETRASO;
    }

    @Override
    public Respuesta solicitarReserva(Libro aLibro) {
        return Respuesta.USER_CON_RETRASO;
    }
}

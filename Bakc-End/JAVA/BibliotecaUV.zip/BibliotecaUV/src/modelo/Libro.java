package modelo;

import java.util.ArrayList;
import modelo.User;
import modelo.Ejemplar;

public class Libro {

    private String isbn;
    private String titulo;
    private String autor;
    private ArrayList<User> users = new ArrayList<User>();
    private Biblioteca biblioteca;
    private ArrayList<Ejemplar> ejemplares = new ArrayList<Ejemplar>();

    public Libro(String aIsbn, String aTitulo, String aAutor) {
        isbn = aIsbn;
        titulo = aTitulo;
        autor = aAutor;
    }

    public Ejemplar buscarEjemplarDisponible() {
        int indice = 0;
        Ejemplar ejemplar;
        Ejemplar ejemplarEncontrado = null;

        while (ejemplarEncontrado == null && indice < ejemplares.size())
        {
            ejemplar = ejemplares.get(indice++);
            
            if (ejemplar.comprobarDisponible())
                    ejemplarEncontrado = ejemplar;
        }
        
        return ejemplarEncontrado;
    }

    public boolean comprobarISBN(String aIsbn) {
        return isbn.equals(aIsbn);
    }

    public void addReserva(User aUser) {
        users.add(aUser);
    }

    public void addEjemplar(Ejemplar aEjemplar) {
        ejemplares.add(aEjemplar);
    }
}

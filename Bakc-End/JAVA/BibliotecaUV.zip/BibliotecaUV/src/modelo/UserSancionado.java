package modelo;

import java.util.Date;

public class UserSancionado extends EstadoUser {

    private Date fechaInicio;
    private Date fechaFin;

    public UserSancionado(User aUser, short aDias) {
        super(aUser);
        fechaInicio = new Date();
        fechaFin = (Date) fechaInicio.clone();
        fechaFin.setDate(fechaFin.getDate() + aDias);
    }

    @Override
    public Respuesta solicitarPrestamo(Libro aLibro) {
        Respuesta prestamoPosible;
        Date hoy=new Date();
        
        if (fechaFin.before(hoy)) {
            new UserPrestamosViables(user);
            prestamoPosible = user.solicitarPrestamo(aLibro);
        }
        else
            prestamoPosible = Respuesta.USER_CON_MULTA;
        return prestamoPosible;
    }

    @Override
    public Respuesta solicitarReserva(Libro aLibro) {
        return Respuesta.USER_CON_MULTA;
    }
}

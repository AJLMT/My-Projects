package modelo;

public abstract class EstadoUser {

    protected User user;

    public EstadoUser(User aUser) {
        user = aUser;
        user.setEstado(this);
    }

    public abstract Respuesta solicitarPrestamo(Libro aLibro);

    public abstract Respuesta solicitarReserva(Libro aLibro);

    public Respuesta ponerMulta(short aDias) {
        new UserSancionado(user, aDias);
        
        return Respuesta.MULTA_IMPUESTA_EXITO;
    }
}
